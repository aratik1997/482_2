$(document).ready(function () {
    $('#loadBtn').click(function () {
       $('#test').load('./demo.txt')
    });
});